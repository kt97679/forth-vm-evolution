strongForth 0.03 beta version



Contents:

1. Introduction
2. Files
3. ANS compliance
4. Next steps
5. Contact



1. Introduction

strongForth is a programming language that is very close to ANS 
Forth. One of the biggest differences is that it includes strong 
static type checking. ANS Forth itself is often called 
"typeless" or "untyped", which means that neither interpreter 
nor compiler do any type-checking when applying a function 
(a "word") to one or more operands. It is completely up to the 
programmer to chose the correct functions. In strongForth, the 
interpreter and the compiler check if a function matches the 
operands on the stack. This allows finding type errors already
at compile time. Additionally, it is possible to overload
operators by using the same name for different functions, as 
long as each function requires a different set of operands. 

The majority of Forth users might believe that strong static 
typing is not Forth-like. Nevertheless, the implementation of
strongForth proves that Forth can incorporate static
typechecking without increasing the complexity of the language.

Although strongForth 0.03 has been tested thoroughly, it is 
highly probable that it still contains several severe bugs. 
Thus, it is only meant to be used for evaluating the static 
typechecking features. It may be used for free, copied and 
given away to others, but it may not be sold, even in a 
modified version. Future versions will include less bugs and 
more features.

strongForth is a pure text-mode application, that will run on 
any compatible PC with DOS 3.3 or higher. It will certainly
also run in the DOS-boxes of Windows 95, Windows 98 and Windows 
NT.



2. Files

The complete package consists of 20 files, which should be 
copied into the same directory:

README.TXT	this file
FORTH.EXE	run this file to start strongForth
FORTH.BLK	200 Forth-blocks
INTRO.HTM	an introduction to strongForth
CROSSREF.HTM	an ANS Forth - strongForth cross reference list
GCORE.HTM	glossary of the Core word set
GCOREX.HTM	glossary of the Core extension word set
GBLOCK.HTM	glossary of the Block word set
GBLOCKX.HTM	glossary of the Block extension word set
GDOUBLE.HTM	glossary of the Double-Number word set
GDOUBLEX.HTM	glossary of the Double-Number extension word set
GLOCALS.HTM	glossary of the Locals word set
GLOCALSX.HTM	glossary of the Locals extension word set
GTOOLS.HTM	glossary of the Programming-Tools word set
GTOOLSX.HTM	glossary of the Programming-Tools extension word set
GSTRING.HTM	glossary of the String word set
GEDITOR.HTM	glossary of the Line editor
EDITOR.HTM	reference of the Line editor
ASM.HTM		reference of the Assembler/Disassembler
SAMPLES.HTM	documentation of the samples in block 70 to 79

Before running FORTH.EXE, the directory containing the above 
mentioned files should be made the working directory. All words 
are defined in upper case only. To exit strongForth, execute
BYE or simply press ^C (control-C).

During execution of FORTH.EXE, all console input and output is
copied into a text file named FORTH.LOG. This feature is for 
evaluation only and will be removed or modified in future 
versions.

Some of the blocks in FORTH.BLK are already filled:

block 1 to 4:	  ANS error messages
block 5 to 16:	  reserved
block 17:	  strongForth-specific error messages
block 18, 19:	  reserved
block 20	  autoexec block
block 21 to 49:	  not used
block 50 to 52:	  source code of the Programming-Tools extension word set
block 53 to 59:   reserved
block 60 to 64:   source code of advanced utility functions (undocumented)
block 65 to 69:   reserved
block 70 to 79:   source code of several samples
block 80 to 88:	  source code of the Programming-Tools word set
block 89:	  reserved
block 90 to 98:   source code of the simple FIG line editor
block 99:	  source code sample from INTRO.HTM
block 100 to 130: source code of the assembler
block 130 to 163: source code of the disassembler
block 164 to 165: strings for the disassembler

The name of a specific block file may be supplied as a 
command-line parameter. To generate a new block file, copy
FORTH.BLK and rename it. To start strongForth with the new 
block file, simply type

FORTH myblocks.BLK

at the command line, where myblocks.BLK is the name of the 
new block file. Without a command-line parameter, 
strongForth starts with the default block file FORTH.BLK.
Note that block files may not be longer than 200 blocks. 
This restriction applies only to the current evaluation 
version and will be removed in later versions.

Block 20 has a special meaning. This block is automatically
LOADed immediately after strongForth has been started. It
will normally contain source code to display a startup 
message and then LOAD other blocks that contain the source 
code of additional word sets and useful utilities.



3. ANS compliance

strongForth is not compliant to ANS Forth. Nevertheless, it 
requires a closer look to see the differences in the source 
code. The simple FIG line editor, which is included in the 
package, looks mostly like standard ANS. The main differences 
are described in INTRO.HTM.

strongForth 0.01 includes the following word sets, which have 
been only slightly modified compared to the standard:

Core
Core extension
Block
Block extension
Double-Number
Double-Number extension
Locals
Locals extension
String

Additionaly, the Programming-Tools and the Programming-Tools 
extension word sets are provided as source code.



4. Next steps

The following improvements will be made in the next versions of 
strongForth:

1. improved documentation
2. Forth model
3. additional word sets
4. words supporting object orientation
5. variable-size data types

According to incoming questions and comments, small improvements 
and additions will be implemented as required.



5. Contact

Questions, comments and new ideas are welcome. Send an email to:

s.becher@t-online.de (Dr. Stephan Becher)

The latest version and up-to-date information are available at:

http://home.t-online.de/home/s.becher/forth

December 3rd, 2000
