/* NOECHO.C

    Vrsn  Date   Comment
    ----|-------|---------------------------------------------------------------
    0.00 02apr95 Adapted from Martin Richards's code.

    Reuben Thomas


    void init_keyb(void)  initialises the keyboard interface.
    void restore_keyb(void) restores the keyboard to its original state.

*/


#define BSD_COMP
#include <stdio.h>
#include <sys/ioctl.h>
#include <sgtty.h>


void init_keyb(void)
{
    struct sgttyb ttyb;

    ioctl(0, TIOCGETP, &ttyb);
    ttyb.sg_flags = CBREAK+EVENP+ODDP+CRMOD;
    ioctl(0, TIOCSETP, &ttyb);
}

void restore_keyb(void)
{
    struct sgttyb ttyb;
    ioctl(0, TIOCGETP, &ttyb);
    ttyb.sg_flags = ECHO+EVENP+ODDP+CRMOD;
    ioctl(0, TIOCSETP, &ttyb);
}
